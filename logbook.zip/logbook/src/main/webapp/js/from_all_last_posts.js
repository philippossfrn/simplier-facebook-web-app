/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//var all_posts_div=document.getElementById("post");
//
//all_posts_div.onclick =function show_from_all_last_posts() {
//    alert("here");
//   send_xmlhttp_request('GET','show_from_all_last_posts?',null,handle_from_all_last_posts_response); 
//};
